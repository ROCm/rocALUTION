/* ************************************************************************
 * Copyright 2018 Advanced Micro Devices, Inc.
 * ************************************************************************ */

/*!\file
 * \brief hipsparse-version.h provides the configured version and settings
 */

#pragma once
#ifndef _HIPSPARSE_VERSION_H_
#define _HIPSPARSE_VERSION_H_

// clang-format off
#define hipsparseVersionMajor 0
#define hipsparseVersionMinor 1
#define hipsparseVersionPatch 0
#define hipsparseVersionTweak 0
// clang-format on

#endif // _HIPSPARSE_VERSION_H_
