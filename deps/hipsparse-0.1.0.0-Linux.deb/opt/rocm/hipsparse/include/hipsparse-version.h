/* ************************************************************************
 * Copyright 2018 Advanced Micro Devices, Inc.
 * ************************************************************************ */

/* the configured version and settings */
#define hipsparseVersionMajor 0
#define hipsparseVersionMinor 1
#define hipsparseVersionPatch 0
#define hipsparseVersionTweak 0
