/* ************************************************************************
 * Copyright 2018 Advanced Micro Devices, Inc.
 * ************************************************************************ */

/*!\file
 * \brief hipsparse-version.h provides the configured version and settings
 */

#pragma once
#ifndef _HIPSPARSE_VERSION_H_
#define _HIPSPARSE_VERSION_H_

// clang-format off
#define hipsparseVersionMajor 0
#define hipsparseVersionMinor 2
#define hipsparseVersionPatch 1
#define hipsparseVersionTweak 0
// clang-format on

#endif // _HIPSPARSE_VERSION_H_
